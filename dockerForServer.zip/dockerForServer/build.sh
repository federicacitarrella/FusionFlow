 sudo docker build --squash -t nextlow/container . 
 

sudo docker run --privileged -t -i nextlow/container
